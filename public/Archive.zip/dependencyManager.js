var possibleCommands = ["DEPEND", "INSTALL", "REMOVE", "LIST"];
var components = [];
var installedComponents = [];
var installedDependencies = [];

function parseCommand(cmdInput) {
  var trimmedCmd = cmdInput.replace(/\s+/g, " "); //Trim extra white space
  var commandArray = trimmedCmd.split(" "); //Turn string into array
  var command = commandArray.shift(); //First in array should presumably be the command

  if (checkCommandValidity(command)) {
    //Check that command is valid
    var component = commandArray.shift(); //second in array is component
    var dependencies = commandArray; //remainder are dependencies

    mapCommandToFunction(command, component, dependencies);
  }
}

function checkCommandValidity(command) {
  return possibleCommands.indexOf(command) > -1;
}

function mapCommandToFunction(command, component, dependencies) {
  //Direct commpand to proper function
  switch (command) {
    case "DEPEND":
      setComponent(component, dependencies);
      break;
    case "LIST":
      listInstalledComponents();
      break;
    case "INSTALL":
      installComponent(component);
      break;
    case "REMOVE":
      removeComponent(component);
      break;
    default:
      break;
  }
}

function setComponent(component, dependencies) {
  var componentObject = { name: component, dependencies: dependencies };

  if (!components.length) {
    components.push(componentObject);
  } else {
    //Check that component isnt set
    components.map(c => {
      if (c.name != component) {
        components.push(componentObject);
      }
    });
  }
}

function installComponent(component) {
  if (!installedComponents.length) {
    installedComponents.push(component);
    console.log("Installing " + component);
  } else {
    //Check that component isnt installed
    installedComponents.map(c => {
      if (c != component) {
        installedComponents.push(component);
        console.log("Installing " + component);
      }
    });
  }
}

function removeComponent(component) {
  checkDependecies(component);

  if (installedComponents.length) {
    var componentPos = installedComponents.indexOf(component);

    console.log("Removing " + component);
    installedComponents.splice(componentPos, 1);
  }
}

function checkDependecies(component) {
  var dependencies = components.filter(r => {
    r === component;

    if (r.name === component) {
      return r.dependencies;
    }

    return null;
  });
  console.log(dependencies);
}

function listInstalledComponents() {
  if (installedComponents.length) {
    installedComponents.map(c => console.log(c));
  }
}

//Test funcionality
function runTestCommands() {
  parseCommand("DEPEND   TELNET TCPIP NETCARD");
  parseCommand("DEPEND TCPIP NETCARD");
  parseCommand("DEPEND DNS TCPIP NETCARD");
  parseCommand("DEPEND  BROWSER   TCPIP  HTML");

  parseCommand("INSTALL NETCARD");
  parseCommand("INSTALL TELNET");

  parseCommand("REMOVE NETCARD");
}

function runListTest() {
  parseCommand("LIST");
}
